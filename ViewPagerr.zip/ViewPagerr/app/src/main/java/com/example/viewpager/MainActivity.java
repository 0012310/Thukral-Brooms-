package com.example.viewpager;

import android.content.Context;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;
import com.example.viewpager.fragments.GamesFragment;
import com.example.viewpager.fragments.MoviesFragment;
import com.example.viewpager.fragments.TopRatedFragment;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TabLayout tabLayoutExploreActivity;
    ViewPager viewpagerExploreActivity;
    Context context;

    TextView user_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = MainActivity.this;

        viewpagerExploreActivity = (ViewPager) findViewById(R.id.viewpagerExploreActivity);
        tabLayoutExploreActivity = (TabLayout) findViewById(R.id.tabLayoutExploreActivity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("ViewPager Example");

        setupViewPager(viewpagerExploreActivity);

        tabLayoutExploreActivity.setupWithViewPager(viewpagerExploreActivity);
        viewpagerExploreActivity.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayoutExploreActivity));


/*
        viewpagerExploreActivity.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
*/

    }

    private void setupViewPager(ViewPager viewPager) {
        viewpagerExploreActivity.setOffscreenPageLimit(1);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new GamesFragment(), "Person Alert");
        adapter.addFragment(new TopRatedFragment(), "Person Search");
        adapter.addFragment(new MoviesFragment(), "Vehicle Alert");
        viewPager.setAdapter(adapter);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {

            mFragmentTitleList.add(title);
            mFragmentList.add(fragment);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }
}
